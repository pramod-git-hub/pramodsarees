
import React, { useState, useEffect } from "react";

export default function MediaSlider({ images = [], video }) {
  const items = [...(images || [])];
  if (video) items.push(video);

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (items.length < 2) return;
    const t = setInterval(() => setCurrent(c => (c + 1) % items.length), 2500);
    return () => clearInterval(t);
  }, [items.length]);

  return (
    <div style={{position:"relative",width:"100%",height:"300px",overflow:"hidden",borderRadius:"8px"}}>
      {items.map((src,i)=>(
        <div key={i} style={{
          opacity: current===i?1:0,
          transition:"opacity .5s",
          position:"absolute",top:0,left:0,width:"100%",height:"100%"
        }}>
          {video && src===video ?
            <video src={src} autoPlay muted loop style={{width:"100%",height:"100%",objectFit:"cover"}}/> :
            <img src={src} style={{width:"100%",height:"100%",objectFit:"cover"}} />
          }
        </div>
      ))}
    </div>
  );
}
